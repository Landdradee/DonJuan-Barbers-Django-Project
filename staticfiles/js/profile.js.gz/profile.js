function toggleSidebar(){
    document.getElementById("sidebar").classList.toggle('active');
  }
  
  function closeNav() {
    document.getElementById("sidebar").classList.toggle('active');
  }
  
  